'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

export default function Home() {
  const [user, setUser] = useState(null);
  const [bookmarks, setBookmarks] = useState([]);
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    fetchBookmarks();
  }, []);

  async function fetchBookmarks() {
    const { data } = await supabase.from('bookmarks').select('*');
    setBookmarks(data || []);
  }

  async function login() {
    await supabase.auth.signInWithOAuth({ provider: 'google' });
  }

  async function addBookmark() {
    if (!title || !url) return;
    await supabase.from('bookmarks').insert([{ title, url }]);
    setTitle('');
    setUrl('');
    fetchBookmarks();
  }

  async function deleteBookmark(id) {
    await supabase.from('bookmarks').delete().eq('id', id);
    fetchBookmarks();
  }

  return (
    <div className="bg-slate-900 p-8 rounded-2xl shadow-2xl w-full max-w-xl">
      <h1 className="text-3xl font-bold mb-6 text-center">Smart Bookmark App</h1>

      {!user ? (
        <button
          onClick={login}
          className="w-full bg-blue-600 hover:bg-blue-700 py-3 rounded-xl font-semibold"
        >
          Login with Google
        </button>
      ) : (
        <>
          <div className="flex gap-2 mb-4">
            <input
              className="flex-1 p-2 rounded-lg text-black"
              placeholder="Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <input
              className="flex-1 p-2 rounded-lg text-black"
              placeholder="URL"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
          </div>
          <button
            onClick={addBookmark}
            className="w-full bg-green-600 hover:bg-green-700 py-2 rounded-xl mb-6"
          >
            Add Bookmark
          </button>

          <ul className="space-y-3">
            {bookmarks.map((bm) => (
              <li
                key={bm.id}
                className="flex justify-between items-center bg-slate-800 p-3 rounded-xl"
              >
                <a href={bm.url} target="_blank" className="text-blue-400">
                  {bm.title}
                </a>
                <button
                  onClick={() => deleteBookmark(bm.id)}
                  className="text-red-400"
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}