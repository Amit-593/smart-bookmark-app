# Smart Bookmark App

## Setup

1. npm install
2. Create a Supabase project
3. Create table:

create table bookmarks (
  id uuid primary key default uuid_generate_v4(),
  title text,
  url text,
  user_id uuid default auth.uid()
);

4. Enable Google OAuth in Supabase
5. Add environment variables in .env.local
6. npm run dev

## Deploy
Push to GitHub → Import into Vercel → Add env variables → Deploy
